from odoo import models

class SalesOrederInher(models.Model):
    _inherit ='sale.order'