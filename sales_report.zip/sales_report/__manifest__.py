{
    'name': "sales report",
    'version':'1.2',
    'summary': 'sales report software',
    'depends':['sale'],
    'data': [
        'report\sales_report.xml',
    ],
    'instalable': True,
    'application': True,
}